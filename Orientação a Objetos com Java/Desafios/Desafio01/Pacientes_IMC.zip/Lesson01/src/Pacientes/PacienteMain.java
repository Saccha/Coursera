package Pacientes;


public class PacienteMain {
public static void main(String[] args) {
		
		
		Paciente paciente01 = new Paciente( 1.67, 70);
		Paciente paciente02 = new Paciente( 1.80, 84.5);
		Paciente paciente03 = new Paciente( 1.20, 48);
		
		
		System.out.println("Paciente 01: \n\tValor do IMC: " + paciente01.calcularIMC()
				 + "\n\tDiagn�stico: " + paciente01.diagnostico());
		System.out.println("Paciente 02: \n\tValor do IMC: " + paciente02.calcularIMC()
				 + "\n\tDiagn�stico: " + paciente02.diagnostico());
		System.out.println("Paciente 03: \n\tvalor do IMC: " + paciente03.calcularIMC()
				 + "\n\tDiagn�stico: " + paciente03.diagnostico());

	}

}
