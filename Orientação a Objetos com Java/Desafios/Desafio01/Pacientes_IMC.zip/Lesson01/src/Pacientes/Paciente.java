package Pacientes;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Paciente {

	double altura, peso;

	
	Paciente(double altura, double peso) {
		this.altura = altura;
		this.peso = peso;
	}


	public double calcularIMC() {
		double IMC = peso / (altura * altura);
		BigDecimal imcArredondar = new BigDecimal(IMC);
		imcArredondar = imcArredondar.setScale(2, RoundingMode.HALF_UP);
		return imcArredondar.doubleValue();
	}

	public String diagnostico() {

		double imc_paciente = calcularIMC();

		if(imc_paciente >= 0.0 && imc_paciente < 16.00){
			return "Baixo peso muito grave";
		}else if(imc_paciente >= 16.00 && imc_paciente <= 16.99){
			return "Baixo peso grave";
		}else if(imc_paciente >= 17.00 && imc_paciente <= 18.49){
			return "Baixo peso";
		}else if(imc_paciente >=  18.50 && imc_paciente <= 24.99){
			return "Peso normal";
		}else if(imc_paciente >= 25.00  && imc_paciente <= 29.99){
			return "Sobrepeso";
		}else if(imc_paciente >= 30.00  && imc_paciente <= 34.99){
			return "Obesidade grau I";
		}else if(imc_paciente >= 35.00  && imc_paciente <= 39.99){
			return "Obesidade grau II";
		}else if(imc_paciente >= 40.00){
			return "Obesidade grau III (obesidade m�rbida)";
		}else {
			//caso retorne valor negativo
			return "IMC inv�lido";
		}

	}

}